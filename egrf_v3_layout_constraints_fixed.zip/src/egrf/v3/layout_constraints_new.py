"""
EGRF v3.0 Layout Constraints System

This module provides a platform-independent layout system for Existential Graph Rendering Format (EGRF).
It enforces Peirce's logical containment rules while giving users freedom to move elements within their
logical containers.

Key components:
- Layout elements (LayoutElement, Viewport)
- Layout context (LayoutContext)
- Constraint system (LayoutConstraint and subclasses)
- Layout management (LayoutManager, ConstraintSolver)
- Visual rule enforcement (VisualRuleEnforcer)
- User interaction validation (UserInteractionValidator)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Any, Union
import math
import json


@dataclass
class LayoutElement:
    """Base class for all layout elements."""
    
    id: str
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0
    
    def get_bounds(self) -> Tuple[float, float, float, float]:
        """Get the bounds of the element as (x, y, width, height)."""
        return (self.x, self.y, self.width, self.height)
    
    def get_center(self) -> Tuple[float, float]:
        """Get the center point of the element as (x, y)."""
        return (self.x + self.width / 2, self.y + self.height / 2)
    
    def contains_point(self, x: float, y: float) -> bool:
        """Check if the element contains the given point."""
        return (
            x >= self.x and
            x <= self.x + self.width and
            y >= self.y and
            y <= self.y + self.height
        )
    
    def intersects(self, other: 'LayoutElement') -> bool:
        """Check if this element intersects with another element."""
        return not (
            self.x + self.width <= other.x or
            other.x + other.width <= self.x or
            self.y + self.height <= other.y or
            other.y + other.height <= self.y
        )
    
    def contains_element(self, other: 'LayoutElement') -> bool:
        """Check if this element fully contains another element."""
        return (
            other.x >= self.x and
            other.x + other.width <= self.x + self.width and
            other.y >= self.y and
            other.y + other.height <= self.y + self.height
        )
    
    def to_json(self) -> Dict[str, Any]:
        """Convert to a JSON-serializable dictionary."""
        return {
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "width": self.width,
            "height": self.height
        }
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'LayoutElement':
        """Create an element from a JSON-serializable dictionary."""
        return cls(
            id=data["id"],
            x=data.get("x", 0.0),
            y=data.get("y", 0.0),
            width=data.get("width", 0.0),
            height=data.get("height", 0.0)
        )


@dataclass
class Viewport(LayoutElement):
    """Viewport for the layout context."""
    
    scale_factor: float = 1.0
    
    def scale_to_device(self, value: float) -> float:
        """Scale a logical value to device pixels."""
        return value * self.scale_factor
    
    def scale_from_device(self, value: float) -> float:
        """Scale a device pixel value to logical units."""
        return value / self.scale_factor
    
    def to_json(self) -> Dict[str, Any]:
        """Convert to a JSON-serializable dictionary."""
        data = super().to_json()
        data["scale_factor"] = self.scale_factor
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'Viewport':
        """Create a viewport from a JSON-serializable dictionary."""
        return cls(
            id=data["id"],
            x=data.get("x", 0.0),
            y=data.get("y", 0.0),
            width=data.get("width", 0.0),
            height=data.get("height", 0.0),
            scale_factor=data.get("scale_factor", 1.0)
        )


@dataclass
class LayoutContext:
    """Context for layout operations."""
    
    elements: Dict[str, LayoutElement]
    containers: Dict[str, str]  # element_id -> container_id
    viewport: Viewport
    constraints: List['LayoutConstraint'] = field(default_factory=list)
    
    def get_element(self, element_id: str) -> Optional[LayoutElement]:
        """Get an element by ID."""
        return self.elements.get(element_id)
    
    def get_container(self, element_id: str) -> Optional[LayoutElement]:
        """Get the container of an element."""
        container_id = self.containers.get(element_id)
        if container_id:
            return self.elements.get(container_id)
        return None
    
    def get_contained_elements(self, container_id: str) -> List[LayoutElement]:
        """Get all elements contained in a container."""
        return [
            self.elements[element_id]
            for element_id, container in self.containers.items()
            if container == container_id and element_id in self.elements
        ]
    
    def get_constraints_for_element(self, element_id: str) -> List['LayoutConstraint']:
        """Get all constraints that apply to an element."""
        return [
            constraint for constraint in self.constraints
            if constraint.applies_to_element(element_id)
        ]
    
    def validate_all_constraints(self) -> Dict[str, bool]:
        """Validate all constraints."""
        return {
            constraint.constraint_id: constraint.validate(self)
            for constraint in self.constraints
        }
    
    def apply_all_constraints(self) -> Dict[str, bool]:
        """Apply all constraints."""
        # Sort constraints by priority (higher priority first)
        sorted_constraints = sorted(
            self.constraints,
            key=lambda c: c.priority,
            reverse=True
        )
        
        results = {}
        for constraint in sorted_constraints:
            try:
                constraint.apply(self)
                results[constraint.constraint_id] = True
            except Exception:
                results[constraint.constraint_id] = False
        
        return results
    
    def to_json(self) -> Dict[str, Any]:
        """Convert to a JSON-serializable dictionary."""
        return {
            "elements": {
                element_id: element.to_json()
                for element_id, element in self.elements.items()
            },
            "containers": self.containers,
            "viewport": self.viewport.to_json(),
            "constraints": [
                constraint.to_json()
                for constraint in self.constraints
            ]
        }
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'LayoutContext':
        """Create a context from a JSON-serializable dictionary."""
        elements = {
            element_id: LayoutElement.from_json(element_data)
            for element_id, element_data in data["elements"].items()
        }
        
        viewport = Viewport.from_json(data["viewport"])
        
        constraints = []
        for constraint_data in data.get("constraints", []):
            constraint_type = constraint_data.get("type")
            if constraint_type == "SizeConstraint":
                constraints.append(SizeConstraint.from_json(constraint_data))
            elif constraint_type == "PositionConstraint":
                constraints.append(PositionConstraint.from_json(constraint_data))
            elif constraint_type == "SpacingConstraint":
                constraints.append(SpacingConstraint.from_json(constraint_data))
            elif constraint_type == "AlignmentConstraint":
                constraints.append(AlignmentConstraint.from_json(constraint_data))
            elif constraint_type == "ContainmentConstraint":
                constraints.append(ContainmentConstraint.from_json(constraint_data))
        
        return cls(
            elements=elements,
            containers=data["containers"],
            viewport=viewport,
            constraints=constraints
        )


# Base constraint class
@dataclass
class LayoutConstraint:
    """Base class for layout constraints."""
    
    constraint_id: str
    element_id: str
    priority: int = 100  # Higher values have higher priority
    
    def applies_to_element(self, element_id: str) -> bool:
        """Check if this constraint applies to the given element."""
        return self.element_id == element_id
    
    def validate(self, context: LayoutContext) -> bool:
        """Validate that the constraint is satisfied."""
        raise NotImplementedError("Subclasses must implement validate()")
    
    def apply(self, context: LayoutContext) -> None:
        """Apply the constraint to the layout context."""
        raise NotImplementedError("Subclasses must implement apply()")
    
    def to_json(self) -> Dict[str, Any]:
        """Convert to a JSON-serializable dictionary."""
        data = {
            "constraint_id": self.constraint_id,
            "element_id": self.element_id,
            "priority": self.priority,
            "type": self.__class__.__name__
        }
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'LayoutConstraint':
        """Create a constraint from a JSON-serializable dictionary."""
        constraint_type = data["type"]
        if constraint_type == "SizeConstraint":
            return SizeConstraint.from_json(data)
        elif constraint_type == "PositionConstraint":
            return PositionConstraint.from_json(data)
        elif constraint_type == "SpacingConstraint":
            return SpacingConstraint.from_json(data)
        elif constraint_type == "AlignmentConstraint":
            return AlignmentConstraint.from_json(data)
        elif constraint_type == "ContainmentConstraint":
            return ContainmentConstraint.from_json(data)
        else:
            raise ValueError(f"Unknown constraint type: {constraint_type}")


# Specific constraint classes
@dataclass
class SizeConstraint(LayoutConstraint):
    """Constraint on element size."""
    
    min_width: Optional[float] = None
    min_height: Optional[float] = None
    max_width: Optional[float] = None
    max_height: Optional[float] = None
    preferred_width: Optional[float] = None
    preferred_height: Optional[float] = None
    aspect_ratio: Optional[float] = None
    maintain_aspect_ratio: bool = False
    
    def validate(self, context: LayoutContext) -> bool:
        """Validate that the size constraint is satisfied."""
        element = context.get_element(self.element_id)
        if not element:
            return False
        
        # Check width constraints
        if self.min_width is not None and element.width < self.min_width:
            return False
        if self.max_width is not None and element.width > self.max_width:
            return False
        
        # Check height constraints
        if self.min_height is not None and element.height < self.min_height:
            return False
        if self.max_height is not None and element.height > self.max_height:
            return False
        
        # Check aspect ratio
        if self.maintain_aspect_ratio and self.aspect_ratio is not None:
            current_ratio = element.width / element.height
            if not math.isclose(current_ratio, self.aspect_ratio, rel_tol=0.05):
                return False
        
        return True
    
    def apply(self, context: LayoutContext) -> None:
        """Apply the size constraint to the element."""
        element = context.get_element(self.element_id)
        if not element:
            return
        
        # Apply width constraints
        if self.preferred_width is not None:
            element.width = self.preferred_width
        elif self.min_width is not None and element.width < self.min_width:
            element.width = self.min_width
        elif self.max_width is not None and element.width > self.max_width:
            element.width = self.max_width
        
        # Apply height constraints
        if self.preferred_height is not None:
            element.height = self.preferred_height
        elif self.min_height is not None and element.height < self.min_height:
            element.height = self.min_height
        elif self.max_height is not None and element.height > self.max_height:
            element.height = self.max_height
        
        # Apply aspect ratio
        if self.maintain_aspect_ratio and self.aspect_ratio is not None:
            current_ratio = element.width / element.height
            if not math.isclose(current_ratio, self.aspect_ratio, rel_tol=0.05):
                # Adjust height based on width
                element.height = element.width / self.aspect_ratio
    
    def to_json(self) -> Dict[str, Any]:
        """Convert the constraint to a JSON-serializable dictionary."""
        data = super().to_json()
        if self.min_width is not None:
            data["min_width"] = self.min_width
        if self.min_height is not None:
            data["min_height"] = self.min_height
        if self.preferred_width is not None:
            data["preferred_width"] = self.preferred_width
        if self.preferred_height is not None:
            data["preferred_height"] = self.preferred_height
        if self.max_width is not None:
            data["max_width"] = self.max_width
        if self.max_height is not None:
            data["max_height"] = self.max_height
        if self.aspect_ratio is not None:
            data["aspect_ratio"] = self.aspect_ratio
        if self.maintain_aspect_ratio:
            data["maintain_aspect_ratio"] = self.maintain_aspect_ratio
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'SizeConstraint':
        """Create a constraint from a JSON-serializable dictionary."""
        return cls(
            constraint_id=data["constraint_id"],
            element_id=data["element_id"],
            priority=data.get("priority", 100),
            min_width=data.get("min_width"),
            min_height=data.get("min_height"),
            max_width=data.get("max_width"),
            max_height=data.get("max_height"),
            preferred_width=data.get("preferred_width"),
            preferred_height=data.get("preferred_height"),
            aspect_ratio=data.get("aspect_ratio"),
            maintain_aspect_ratio=data.get("maintain_aspect_ratio", False)
        )


@dataclass
class PositionConstraint(LayoutConstraint):
    """Constraint on element position relative to another element or container."""
    
    reference_id: str  # ID of reference element or container
    reference_point: str = "center"  # center, top-left, top-right, bottom-left, bottom-right
    element_point: str = "center"  # center, top-left, top-right, bottom-left, bottom-right
    offset_x: float = 0.0
    offset_y: float = 0.0
    
    def validate(self, context: LayoutContext) -> bool:
        """Validate that the position constraint is satisfied."""
        element = context.get_element(self.element_id)
        reference = context.get_element(self.reference_id)
        
        if not element or not reference:
            return False
        
        # Get reference point coordinates
        ref_x, ref_y = self._get_point_coordinates(reference, self.reference_point)
        
        # Get element point coordinates
        elem_x, elem_y = self._get_point_coordinates(element, self.element_point)
        
        # Check if the points match with the offset
        return (
            math.isclose(elem_x, ref_x + self.offset_x, abs_tol=0.5) and
            math.isclose(elem_y, ref_y + self.offset_y, abs_tol=0.5)
        )
    
    def apply(self, context: LayoutContext) -> None:
        """Apply the position constraint to the element."""
        element = context.get_element(self.element_id)
        reference = context.get_element(self.reference_id)
        
        if not element or not reference:
            return
        
        # Get reference point coordinates
        ref_x, ref_y = self._get_point_coordinates(reference, self.reference_point)
        
        # Calculate the new position for the element
        if self.element_point == "center":
            element.x = ref_x + self.offset_x - element.width / 2
            element.y = ref_y + self.offset_y - element.height / 2
        elif self.element_point == "top-left":
            element.x = ref_x + self.offset_x
            element.y = ref_y + self.offset_y
        elif self.element_point == "top-right":
            element.x = ref_x + self.offset_x - element.width
            element.y = ref_y + self.offset_y
        elif self.element_point == "bottom-left":
            element.x = ref_x + self.offset_x
            element.y = ref_y + self.offset_y - element.height
        elif self.element_point == "bottom-right":
            element.x = ref_x + self.offset_x - element.width
            element.y = ref_y + self.offset_y - element.height
    
    def _get_point_coordinates(self, element: LayoutElement, point: str) -> Tuple[float, float]:
        """Get the coordinates of a specific point on an element."""
        if point == "center":
            return (element.x + element.width / 2, element.y + element.height / 2)
        elif point == "top-left":
            return (element.x, element.y)
        elif point == "top-right":
            return (element.x + element.width, element.y)
        elif point == "bottom-left":
            return (element.x, element.y + element.height)
        elif point == "bottom-right":
            return (element.x + element.width, element.y + element.height)
        else:
            return (element.x, element.y)  # Default to top-left
    
    def to_json(self) -> Dict[str, Any]:
        """Convert the constraint to a JSON-serializable dictionary."""
        data = super().to_json()
        data["reference_id"] = self.reference_id
        data["reference_point"] = self.reference_point
        data["element_point"] = self.element_point
        data["offset_x"] = self.offset_x
        data["offset_y"] = self.offset_y
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'PositionConstraint':
        """Create a constraint from a JSON-serializable dictionary."""
        return cls(
            constraint_id=data["constraint_id"],
            element_id=data["element_id"],
            priority=data.get("priority", 100),
            reference_id=data["reference_id"],
            reference_point=data.get("reference_point", "center"),
            element_point=data.get("element_point", "center"),
            offset_x=data.get("offset_x", 0.0),
            offset_y=data.get("offset_y", 0.0)
        )


@dataclass
class SpacingConstraint(LayoutConstraint):
    """Constraint on spacing between elements or to container edges."""
    
    min_spacing: float
    reference_id: str  # If empty string, applies to container
    max_spacing: Optional[float] = None
    preferred_spacing: Optional[float] = None
    edge: Optional[str] = None  # top, right, bottom, left; if None, applies to all edges
    
    def validate(self, context: LayoutContext) -> bool:
        """Validate that the spacing constraint is satisfied."""
        element = context.get_element(self.element_id)
        if not element:
            return False
        
        if self.reference_id:
            # Spacing between elements
            reference = context.get_element(self.reference_id)
            if not reference:
                return False
            
            spacing = self._get_spacing(element, reference)
            
            if self.min_spacing is not None and spacing < self.min_spacing:
                return False
            if self.max_spacing is not None and spacing > self.max_spacing:
                return False
        else:
            # Spacing to container edges
            container = context.get_container(self.element_id)
            if not container:
                return True  # No container means constraint is satisfied
            
            if self.edge is None or self.edge == "left":
                spacing = element.x - container.x
                if self.min_spacing is not None and spacing < self.min_spacing:
                    return False
                if self.max_spacing is not None and spacing > self.max_spacing:
                    return False
            
            if self.edge is None or self.edge == "right":
                spacing = (container.x + container.width) - (element.x + element.width)
                if self.min_spacing is not None and spacing < self.min_spacing:
                    return False
                if self.max_spacing is not None and spacing > self.max_spacing:
                    return False
            
            if self.edge is None or self.edge == "top":
                spacing = element.y - container.y
                if self.min_spacing is not None and spacing < self.min_spacing:
                    return False
                if self.max_spacing is not None and spacing > self.max_spacing:
                    return False
            
            if self.edge is None or self.edge == "bottom":
                spacing = (container.y + container.height) - (element.y + element.height)
                if self.min_spacing is not None and spacing < self.min_spacing:
                    return False
                if self.max_spacing is not None and spacing > self.max_spacing:
                    return False
        
        return True
    
    def apply(self, context: LayoutContext) -> None:
        """Apply the spacing constraint to the element."""
        element = context.get_element(self.element_id)
        if not element:
            return
        
        if self.reference_id:
            # Spacing between elements
            reference = context.get_element(self.reference_id)
            if not reference:
                return
            
            spacing = self._get_spacing(element, reference)
            target_spacing = self.preferred_spacing if self.preferred_spacing is not None else self.min_spacing
            
            if spacing < target_spacing:
                # Move element to satisfy spacing
                if self.edge == "left":
                    element.x = reference.x - element.width - target_spacing
                elif self.edge == "right":
                    element.x = reference.x + reference.width + target_spacing
                elif self.edge == "top":
                    element.y = reference.y - element.height - target_spacing
                elif self.edge == "bottom":
                    element.y = reference.y + reference.height + target_spacing
        else:
            # Spacing to container edges
            container = context.get_container(self.element_id)
            if not container:
                return
            
            target_spacing = self.preferred_spacing if self.preferred_spacing is not None else self.min_spacing
            
            if self.edge is None or self.edge == "left":
                if element.x - container.x < target_spacing:
                    element.x = container.x + target_spacing
            
            if self.edge is None or self.edge == "right":
                if container.x + container.width - (element.x + element.width) < target_spacing:
                    element.x = container.x + container.width - element.width - target_spacing
            
            if self.edge is None or self.edge == "top":
                if element.y - container.y < target_spacing:
                    element.y = container.y + target_spacing
            
            if self.edge is None or self.edge == "bottom":
                if container.y + container.height - (element.y + element.height) < target_spacing:
                    element.y = container.y + container.height - element.height - target_spacing
    
    def _get_spacing(self, element: LayoutElement, reference: LayoutElement) -> float:
        """Get the spacing between two elements based on the edge."""
        if self.edge == "left":
            return element.x - (reference.x + reference.width)
        elif self.edge == "right":
            return reference.x - (element.x + element.width)
        elif self.edge == "top":
            return element.y - (reference.y + reference.height)
        elif self.edge == "bottom":
            return reference.y - (element.y + element.height)
        else:
            # Default to minimum spacing on any edge
            left_spacing = element.x - (reference.x + reference.width)
            right_spacing = reference.x - (element.x + element.width)
            top_spacing = element.y - (reference.y + reference.height)
            bottom_spacing = reference.y - (element.y + element.height)
            return min(left_spacing, right_spacing, top_spacing, bottom_spacing)
    
    def to_json(self) -> Dict[str, Any]:
        """Convert the constraint to a JSON-serializable dictionary."""
        data = super().to_json()
        data["min_spacing"] = self.min_spacing
        data["reference_id"] = self.reference_id
        if self.max_spacing is not None:
            data["max_spacing"] = self.max_spacing
        if self.preferred_spacing is not None:
            data["preferred_spacing"] = self.preferred_spacing
        if self.edge is not None:
            data["edge"] = self.edge
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'SpacingConstraint':
        """Create a constraint from a JSON-serializable dictionary."""
        return cls(
            constraint_id=data["constraint_id"],
            element_id=data["element_id"],
            priority=data.get("priority", 100),
            min_spacing=data["min_spacing"],
            reference_id=data.get("reference_id", ""),
            max_spacing=data.get("max_spacing"),
            preferred_spacing=data.get("preferred_spacing"),
            edge=data.get("edge")
        )


@dataclass
class AlignmentConstraint(LayoutConstraint):
    """Constraint on element alignment with another element."""
    
    reference_id: str  # ID of reference element
    alignment: str  # center, left, right, top, bottom, center-horizontal, center-vertical
    offset: float = 0.0
    
    def validate(self, context: LayoutContext) -> bool:
        """Validate that the alignment constraint is satisfied."""
        element = context.get_element(self.element_id)
        reference = context.get_element(self.reference_id)
        
        if not element or not reference:
            return False
        
        if self.alignment == "center":
            return (
                math.isclose(element.x + element.width / 2, reference.x + reference.width / 2 + self.offset, abs_tol=0.5) and
                math.isclose(element.y + element.height / 2, reference.y + reference.height / 2 + self.offset, abs_tol=0.5)
            )
        elif self.alignment == "center-horizontal":
            return math.isclose(element.x + element.width / 2, reference.x + reference.width / 2 + self.offset, abs_tol=0.5)
        elif self.alignment == "center-vertical":
            return math.isclose(element.y + element.height / 2, reference.y + reference.height / 2 + self.offset, abs_tol=0.5)
        elif self.alignment == "left":
            return math.isclose(element.x, reference.x + self.offset, abs_tol=0.5)
        elif self.alignment == "right":
            return math.isclose(element.x + element.width, reference.x + reference.width + self.offset, abs_tol=0.5)
        elif self.alignment == "top":
            return math.isclose(element.y, reference.y + self.offset, abs_tol=0.5)
        elif self.alignment == "bottom":
            return math.isclose(element.y + element.height, reference.y + reference.height + self.offset, abs_tol=0.5)
        else:
            return False
    
    def apply(self, context: LayoutContext) -> None:
        """Apply the alignment constraint to the element."""
        element = context.get_element(self.element_id)
        reference = context.get_element(self.reference_id)
        
        if not element or not reference:
            return
        
        if self.alignment == "center" or self.alignment == "center-horizontal":
            element.x = reference.x + reference.width / 2 - element.width / 2 + self.offset
        
        if self.alignment == "center" or self.alignment == "center-vertical":
            element.y = reference.y + reference.height / 2 - element.height / 2 + self.offset
        
        if self.alignment == "left":
            element.x = reference.x + self.offset
        
        if self.alignment == "right":
            element.x = reference.x + reference.width - element.width + self.offset
        
        if self.alignment == "top":
            element.y = reference.y + self.offset
        
        if self.alignment == "bottom":
            element.y = reference.y + reference.height - element.height + self.offset
    
    def to_json(self) -> Dict[str, Any]:
        """Convert the constraint to a JSON-serializable dictionary."""
        data = super().to_json()
        data["reference_id"] = self.reference_id
        data["alignment"] = self.alignment
        data["offset"] = self.offset
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'AlignmentConstraint':
        """Create a constraint from a JSON-serializable dictionary."""
        return cls(
            constraint_id=data["constraint_id"],
            element_id=data["element_id"],
            priority=data.get("priority", 100),
            reference_id=data["reference_id"],
            alignment=data["alignment"],
            offset=data.get("offset", 0.0)
        )


@dataclass
class ContainmentConstraint(LayoutConstraint):
    """Constraint ensuring an element stays within its container."""
    
    padding: float = 0.0
    
    def validate(self, context: LayoutContext) -> bool:
        """Validate that the containment constraint is satisfied."""
        element = context.get_element(self.element_id)
        container = context.get_container(self.element_id)
        
        if not element:
            return False
        
        if not container:
            return True  # No container means constraint is satisfied
        
        # Check if element is fully contained within container with padding
        return (
            element.x >= container.x + self.padding and
            element.y >= container.y + self.padding and
            element.x + element.width <= container.x + container.width - self.padding and
            element.y + element.height <= container.y + container.height - self.padding
        )
    
    def apply(self, context: LayoutContext) -> None:
        """Apply the containment constraint to the element."""
        element = context.get_element(self.element_id)
        container = context.get_container(self.element_id)
        
        if not element or not container:
            return
        
        # Ensure element is within container bounds with padding
        if element.x < container.x + self.padding:
            element.x = container.x + self.padding
        
        if element.y < container.y + self.padding:
            element.y = container.y + self.padding
        
        if element.x + element.width > container.x + container.width - self.padding:
            # If element is too wide, try to move it left
            if element.width <= container.width - 2 * self.padding:
                element.x = container.x + container.width - element.width - self.padding
            else:
                # Element is too wide for container, resize it
                element.width = container.width - 2 * self.padding
                element.x = container.x + self.padding
        
        if element.y + element.height > container.y + container.height - self.padding:
            # If element is too tall, try to move it up
            if element.height <= container.height - 2 * self.padding:
                element.y = container.y + container.height - element.height - self.padding
            else:
                # Element is too tall for container, resize it
                element.height = container.height - 2 * self.padding
                element.y = container.y + self.padding
    
    def to_json(self) -> Dict[str, Any]:
        """Convert the constraint to a JSON-serializable dictionary."""
        data = super().to_json()
        data["padding"] = self.padding
        return data
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'ContainmentConstraint':
        """Create a constraint from a JSON-serializable dictionary."""
        return cls(
            constraint_id=data["constraint_id"],
            element_id=data["element_id"],
            priority=data.get("priority", 100),
            padding=data.get("padding", 0.0)
        )


class CollisionDetector:
    """Detects and resolves collisions between elements."""
    
    def detect_collisions(self, context: LayoutContext) -> List[Tuple[str, str]]:
        """Detect collisions between elements."""
        collisions = []
        elements = list(context.elements.values())
        
        for i in range(len(elements)):
            for j in range(i + 1, len(elements)):
                element1 = elements[i]
                element2 = elements[j]
                
                # Skip if elements are in different containers
                container1 = context.containers.get(element1.id)
                container2 = context.containers.get(element2.id)
                if container1 != container2:
                    continue
                
                if element1.intersects(element2):
                    collisions.append((element1.id, element2.id))
        
        return collisions
    
    def resolve_collisions(self, context: LayoutContext) -> bool:
        """Resolve collisions between elements."""
        collisions = self.detect_collisions(context)
        if not collisions:
            return True
        
        for element1_id, element2_id in collisions:
            element1 = context.get_element(element1_id)
            element2 = context.get_element(element2_id)
            
            if not element1 or not element2:
                continue
            
            # Calculate centers
            center1_x = element1.x + element1.width / 2
            center1_y = element1.y + element1.height / 2
            center2_x = element2.x + element2.width / 2
            center2_y = element2.y + element2.height / 2
            
            # Calculate direction vector
            dx = center2_x - center1_x
            dy = center2_y - center1_y
            
            # Calculate minimum distance to separate
            min_dist_x = (element1.width + element2.width) / 2
            min_dist_y = (element1.height + element2.height) / 2
            
            # Move elements apart
            if abs(dx) / min_dist_x < abs(dy) / min_dist_y:
                # Move vertically
                if dy > 0:
                    element1.y -= min_dist_y - abs(dy)
                    element2.y += min_dist_y - abs(dy)
                else:
                    element1.y += min_dist_y - abs(dy)
                    element2.y -= min_dist_y - abs(dy)
            else:
                # Move horizontally
                if dx > 0:
                    element1.x -= min_dist_x - abs(dx)
                    element2.x += min_dist_x - abs(dx)
                else:
                    element1.x += min_dist_x - abs(dx)
                    element2.x -= min_dist_x - abs(dx)
        
        # Check if all collisions were resolved
        return len(self.detect_collisions(context)) == 0


class ConstraintSolver:
    """Solves layout constraints."""
    
    def __init__(self, max_iterations: int = 10, convergence_threshold: float = 0.1):
        self.max_iterations = max_iterations
        self.convergence_threshold = convergence_threshold
    
    def solve(self, context: LayoutContext) -> bool:
        """Solve all constraints in the context."""
        # Sort constraints by priority (higher priority first)
        sorted_constraints = sorted(
            context.constraints,
            key=lambda c: c.priority,
            reverse=True
        )
        
        # Apply constraints iteratively until convergence or max iterations
        for iteration in range(self.max_iterations):
            # Save current element positions
            prev_positions = {
                element_id: (element.x, element.y, element.width, element.height)
                for element_id, element in context.elements.items()
            }
            
            # Apply all constraints
            for constraint in sorted_constraints:
                constraint.apply(context)
            
            # Check for convergence
            max_delta = 0.0
            for element_id, element in context.elements.items():
                prev_x, prev_y, prev_width, prev_height = prev_positions[element_id]
                delta_x = abs(element.x - prev_x)
                delta_y = abs(element.y - prev_y)
                delta_width = abs(element.width - prev_width)
                delta_height = abs(element.height - prev_height)
                max_delta = max(max_delta, delta_x, delta_y, delta_width, delta_height)
            
            if max_delta < self.convergence_threshold:
                break
        
        # Validate all constraints
        results = context.validate_all_constraints()
        return all(results.values())


class VisualRuleEnforcer:
    """Enforces visual rules for Peirce's Existential Graphs."""
    
    def enforce_rules(self, context: LayoutContext) -> bool:
        """Enforce all visual rules."""
        success = True
        
        # Enforce nesting rules
        if not self._enforce_nesting_rules(context):
            success = False
        
        # Enforce predicate placement rules
        if not self._enforce_predicate_placement_rules(context):
            success = False
        
        # Enforce entity connection rules
        if not self._enforce_entity_connection_rules(context):
            success = False
        
        return success
    
    def _enforce_nesting_rules(self, context: LayoutContext) -> bool:
        """Enforce rules for nested contexts."""
        success = True
        
        # Ensure all elements are within their containers
        for element_id, container_id in context.containers.items():
            element = context.get_element(element_id)
            container = context.get_element(container_id)
            
            if not element or not container:
                continue
            
            if not container.contains_element(element):
                # Move element inside container
                if element.x < container.x:
                    element.x = container.x
                if element.y < container.y:
                    element.y = container.y
                if element.x + element.width > container.x + container.width:
                    if element.width <= container.width:
                        element.x = container.x + container.width - element.width
                    else:
                        element.width = container.width
                        element.x = container.x
                if element.y + element.height > container.y + container.height:
                    if element.height <= container.height:
                        element.y = container.y + container.height - element.height
                    else:
                        element.height = container.height
                        element.y = container.y
                
                success = False
        
        return success
    
    def _enforce_predicate_placement_rules(self, context: LayoutContext) -> bool:
        """Enforce rules for predicate placement."""
        # In a real implementation, this would enforce rules specific to predicates
        # For now, we'll just return True
        return True
    
    def _enforce_entity_connection_rules(self, context: LayoutContext) -> bool:
        """Enforce rules for entity connections."""
        # In a real implementation, this would enforce rules for entity connections
        # For now, we'll just return True
        return True


class UserInteractionValidator:
    """Validates user interactions with the layout."""
    
    def __init__(self):
        self.collision_detector = CollisionDetector()
    
    def validate_move(self, context: LayoutContext, element_id: str, new_x: float, new_y: float) -> bool:
        """Validate a move interaction."""
        element = context.get_element(element_id)
        if not element:
            return False
        
        # Save original position
        original_x = element.x
        original_y = element.y
        
        # Temporarily move element
        element.x = new_x
        element.y = new_y
        
        # Check containment
        container = context.get_container(element_id)
        if container and not container.contains_element(element):
            # Restore original position
            element.x = original_x
            element.y = original_y
            return False
        
        # Check collisions
        collisions = self.collision_detector.detect_collisions(context)
        if collisions:
            # Restore original position
            element.x = original_x
            element.y = original_y
            return False
        
        # Check constraints
        constraints = context.get_constraints_for_element(element_id)
        for constraint in constraints:
            if not constraint.validate(context):
                # Restore original position
                element.x = original_x
                element.y = original_y
                return False
        
        # Restore original position
        element.x = original_x
        element.y = original_y
        
        return True
    
    def validate_resize(self, context: LayoutContext, element_id: str, new_width: float, new_height: float) -> bool:
        """Validate a resize interaction."""
        element = context.get_element(element_id)
        if not element:
            return False
        
        # Save original size
        original_width = element.width
        original_height = element.height
        
        # Temporarily resize element
        element.width = new_width
        element.height = new_height
        
        # Check containment
        container = context.get_container(element_id)
        if container and not container.contains_element(element):
            # Restore original size
            element.width = original_width
            element.height = original_height
            return False
        
        # Check collisions
        collisions = self.collision_detector.detect_collisions(context)
        if collisions:
            # Restore original size
            element.width = original_width
            element.height = original_height
            return False
        
        # Check constraints
        constraints = context.get_constraints_for_element(element_id)
        for constraint in constraints:
            if not constraint.validate(context):
                # Restore original size
                element.width = original_width
                element.height = original_height
                return False
        
        # Restore original size
        element.width = original_width
        element.height = original_height
        
        return True


class LayoutManager:
    """Manages layout operations."""
    
    def __init__(self):
        self.constraint_solver = ConstraintSolver()
        self.collision_detector = CollisionDetector()
        self.visual_rule_enforcer = VisualRuleEnforcer()
        self.user_interaction_validator = UserInteractionValidator()
    
    def solve_layout(self, context: LayoutContext) -> bool:
        """Solve the layout for the given context."""
        # Solve constraints
        if not self.constraint_solver.solve(context):
            return False
        
        # Resolve collisions
        if not self.collision_detector.resolve_collisions(context):
            return False
        
        # Enforce visual rules
        if not self.visual_rule_enforcer.enforce_rules(context):
            return False
        
        return True
    
    def auto_layout(self, context: LayoutContext) -> bool:
        """Automatically layout elements in a grid."""
        # Get all elements that need to be laid out
        elements = list(context.elements.values())
        if not elements:
            return True
        
        # Calculate grid dimensions
        count = len(elements)
        cols = int(math.sqrt(count))
        rows = (count + cols - 1) // cols  # Ceiling division
        
        # Calculate cell size
        max_width = max(element.width for element in elements)
        max_height = max(element.height for element in elements)
        cell_width = max_width * 1.2  # Add some spacing
        cell_height = max_height * 1.2  # Add some spacing
        
        # Position elements in grid
        for i, element in enumerate(elements):
            row = i // cols
            col = i % cols
            
            # Center element in its cell
            element.x = col * cell_width + (cell_width - element.width) / 2
            element.y = row * cell_height + (cell_height - element.height) / 2
    
    def validate_user_interaction(self, context: LayoutContext, interaction_type: str, element_id: str, **kwargs) -> bool:
        """Validate a user interaction."""
        if interaction_type == "move":
            return self.user_interaction_validator.validate_move(
                context, element_id, kwargs.get("new_x"), kwargs.get("new_y")
            )
        elif interaction_type == "resize":
            return self.user_interaction_validator.validate_resize(
                context, element_id, kwargs.get("new_width"), kwargs.get("new_height")
            )
        else:
            return False

